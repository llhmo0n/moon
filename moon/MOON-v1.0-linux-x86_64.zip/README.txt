MOON v1.0 – La plata digital
Lanzado el 29 de noviembre de 2025 por KNKIBloque génesis:50 MOON → MC7GUBTOENK3BFW5GGHIDN7R5UQ3MF37QHash: 9041ec7b7f67cda2922f4a3be64ff0ab1c401a297839b0678caf9c48f2d4f386Supply máximo: 21.000.000 MOONRecompensa actual: 50 MOON por bloqueEjecutar: ./moonKNKI
